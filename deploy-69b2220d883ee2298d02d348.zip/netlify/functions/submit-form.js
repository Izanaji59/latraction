const { Pool } = require('pg');
const querystring = require('querystring');

const pool = new Pool({
  connectionString: process.env.NETLIFY_DATABASE_URL,
  ssl: { rejectUnauthorized: false }
});

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ success: false, message: 'Méthode non autorisée' })
    };
  }

  try {
    const contentType = event.headers['content-type'] || event.headers['Content-Type'] || '';
    let data = {};

    if (contentType.includes('application/json')) {
      data = JSON.parse(event.body || '{}');
    } else {
      // Parser les données URL-encodées avec querystring
      const parsed = querystring.parse(event.body || '');
      data = {
        name: (parsed.name || '').trim(),
        email: (parsed.email || '').trim(),
        phone: (parsed.phone || '').trim() || null,
        service: (parsed.service || '').trim() || null,
        message: (parsed.message || '').trim(),
        // Nouveaux champs pour le formulaire énergie
        city: (parsed.city || '').trim() || null,
        placeType: (parsed['place-type'] || '').trim() || null,
        surface: (parsed.surface || '').trim() || null,
        hub: (parsed.hub || '').trim() || null,
        page: (parsed.page || '').trim() || null,
        source: (parsed.source || '').trim() || null
      };
    }

    // Validation
    if (!data.name || !data.email || !data.message) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        },
        body: JSON.stringify({
          success: false,
          message: 'Veuillez remplir tous les champs obligatoires.'
        })
      };
    }

    // Construire le message enrichi avec les informations supplémentaires
    let enrichedMessage = data.message;
    const additionalInfo = [];
    
    if (data.city) additionalInfo.push(`Ville: ${data.city}`);
    if (data.placeType) additionalInfo.push(`Type de lieu: ${data.placeType}`);
    if (data.surface) additionalInfo.push(`Surface: ${data.surface} m²`);
    if (data.hub) additionalInfo.push(`Hub: ${data.hub}`);
    if (data.page) additionalInfo.push(`Page: ${data.page}`);
    if (data.source) additionalInfo.push(`Source: ${data.source}`);
    
    if (additionalInfo.length > 0) {
      enrichedMessage = `${data.message}\n\n--- Informations supplémentaires ---\n${additionalInfo.join('\n')}`;
    }
    
    // Construire le service enrichi si nécessaire
    let enrichedService = data.service;
    if (data.hub && !enrichedService) {
      enrichedService = data.hub;
    }

    // Insérer dans la base de données
    const result = await pool.query(
      `INSERT INTO contacts (name, email, phone, service, message, status, created_at)
       VALUES ($1, $2, $3, $4, $5, 'new', NOW())
       RETURNING id`,
      [data.name, data.email, data.phone, enrichedService, enrichedMessage]
    );

    console.log('Données enregistrées avec succès, ID:', result.rows[0].id);

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: true,
        message: 'Votre demande a été enregistrée avec succès. Nous vous contacterons sous 24h.'
      })
    };
  } catch (error) {
    console.error('Erreur détaillée:', error);
    console.error('Stack:', error.stack);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        success: false,
        message: 'Une erreur est survenue lors de l\'envoi du formulaire.',
        error: process.env.NODE_ENV === 'development' ? error.message : undefined
      })
    };
  }
};