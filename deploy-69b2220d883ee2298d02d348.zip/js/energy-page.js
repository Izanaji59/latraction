/**
 * Script minimal pour la page Énergie
 * Gère les animations au scroll avec respect de prefers-reduced-motion
 */

(function() {
    'use strict';
    
    // Vérifier si on est sur la page énergie
    if (!document.body.hasAttribute('data-hub') || document.body.getAttribute('data-hub') !== 'energy') {
        return;
    }
    
    // Respecter prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (prefersReducedMotion) {
        // Si l'utilisateur préfère réduire les animations, rendre tout visible immédiatement
        document.querySelectorAll('.energy-prestation-card, .energy-segment-card, .energy-timeline-step').forEach(el => {
            el.classList.add('energy-visible');
        });
        return;
    }
    
    // Intersection Observer pour les animations au scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('energy-visible');
                // Optionnel: arrêter d'observer une fois visible
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    // Observer les éléments à animer
    document.querySelectorAll('.energy-prestation-card, .energy-segment-card, .energy-timeline-step').forEach(el => {
        observer.observe(el);
    });
    
    // Animation avec délai pour les cartes de prestations
    const prestationCards = document.querySelectorAll('.energy-prestation-card');
    prestationCards.forEach((card, index) => {
        card.style.transitionDelay = `${index * 0.1}s`;
    });
    
    // Animation avec délai pour les segments
    const segmentCards = document.querySelectorAll('.energy-segment-card');
    segmentCards.forEach((card, index) => {
        card.style.transitionDelay = `${index * 0.1}s`;
    });
    
    // Animation avec délai pour la timeline
    const timelineSteps = document.querySelectorAll('.energy-timeline-step');
    timelineSteps.forEach((step, index) => {
        step.style.transitionDelay = `${index * 0.15}s`;
    });
    
})();
