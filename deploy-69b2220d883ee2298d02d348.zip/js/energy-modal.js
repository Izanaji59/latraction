/**
 * Script pour la modal de formulaire Énergie
 * Gère l'ouverture/fermeture, focus trap, et pré-remplissage
 */

(function() {
    'use strict';
    
    // Vérifier si on est sur la page énergie
    if (!document.body.hasAttribute('data-hub') || document.body.getAttribute('data-hub') !== 'energy') {
        return;
    }
    
    const modal = document.getElementById('energyModal');
    const form = document.getElementById('energyForm');
    let focusableElements = [];
    let firstFocusableElement = null;
    let lastFocusableElement = null;
    
    // Configuration des placeholders selon le besoin
    const BESOIN_PLACEHOLDERS = {
        'contrat-maintenance': 'Décrivez vos installations et vos besoins de maintenance...',
        'analyse-consommation': 'Décrivez vos consommations actuelles et vos objectifs...',
        'diagnostic-energetique': 'Décrivez votre situation actuelle et vos objectifs...',
        'optimisation': 'Décrivez vos installations et les optimisations souhaitées...',
        'etude-technique': 'Décrivez votre projet et vos besoins d\'étude...',
        'mise-a-niveau-remplacement': 'Décrivez les équipements à remplacer ou moderniser...',
        'froid-ventilation': 'Décrivez vos besoins en froid et ventilation...'
    };
    
    // Fonction pour mettre à jour les champs dynamiques selon le besoin
    function updateFormFields() {
        const besoinSelect = document.getElementById('energy-besoin');
        const messageTextarea = document.getElementById('energy-message');
        
        if (!besoinSelect || !messageTextarea) return;
        
        const besoin = besoinSelect.value;
        
        // Mettre à jour le placeholder du message
        if (besoin && BESOIN_PLACEHOLDERS[besoin]) {
            messageTextarea.placeholder = BESOIN_PLACEHOLDERS[besoin];
        } else {
            messageTextarea.placeholder = 'Décrivez votre besoin...';
        }
    }
    
    // Fonction pour ouvrir la modal
    window.openEnergyModal = function(type, besoin) {
        if (!modal) return;
        
        const besoinSelect = document.getElementById('energy-besoin');
        
        // Pré-remplir selon le type
        if (type === 'maintenance') {
            if (besoinSelect) {
                besoinSelect.value = 'contrat-maintenance';
            }
        } else if (type === 'diagnostic') {
            if (besoinSelect) {
                besoinSelect.value = 'diagnostic-energetique';
            }
        } else if (type === 'etude') {
            if (besoinSelect) {
                besoinSelect.value = 'etude-technique';
            }
        } else if (type === 'mise-a-niveau') {
            if (besoinSelect) {
                besoinSelect.value = 'mise-a-niveau-remplacement';
            }
        } else if (type === 'froid-ventilation') {
            if (besoinSelect) {
                besoinSelect.value = 'froid-ventilation';
            }
        }
        
        // Pré-remplir le besoin spécifique si fourni
        if (besoin && besoinSelect) {
            const besoinMap = {
                'maintenance-preventive': 'contrat-maintenance',
                'maintenance-corrective': 'contrat-maintenance',
                'suivi-exploitation': 'contrat-maintenance',
                'analyse-consommation': 'analyse-consommation',
                'optimisation': 'optimisation'
            };
            if (besoinMap[besoin]) {
                besoinSelect.value = besoinMap[besoin];
            }
        }
        
        // Afficher la modal
        modal.style.display = 'flex';
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
        
        // Mettre à jour les champs dynamiques
        updateFormFields();
        
        // Mettre à jour les éléments focusables
        updateFocusableElements();
        
        // Focus sur le premier champ
        if (firstFocusableElement) {
            setTimeout(() => {
                firstFocusableElement.focus();
            }, 100);
        }
        
        // Ajouter l'écouteur ESC
        document.addEventListener('keydown', handleEscape);
    };
    
    // Fonction pour fermer la modal
    window.closeEnergyModal = function() {
        if (!modal) return;
        
        modal.style.display = 'none';
        modal.classList.remove('show');
        document.body.style.overflow = '';
        
        // Retirer l'écouteur ESC
        document.removeEventListener('keydown', handleEscape);
        
        // Réinitialiser le formulaire et retirer les messages
        if (form) {
            form.reset();
            form.style.display = 'block';
            
            // Retirer les messages de succès/erreur s'ils existent
            const successMessage = document.querySelector('.energy-form-success');
            if (successMessage) {
                successMessage.remove();
            }
            const errorMessage = document.querySelector('.energy-form-error');
            if (errorMessage) {
                errorMessage.remove();
            }
        }
    };
    
    // Gérer la touche ESC
    function handleEscape(event) {
        if (event.key === 'Escape' && modal.style.display === 'flex') {
            closeEnergyModal();
        }
    }
    
    // Mettre à jour la liste des éléments focusables
    function updateFocusableElements() {
        if (!modal) return;
        
        const selector = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
        focusableElements = Array.from(modal.querySelectorAll(selector))
            .filter(el => {
                return !el.disabled && 
                       el.offsetParent !== null && 
                       !el.hasAttribute('aria-hidden');
            });
        
        firstFocusableElement = focusableElements[0];
        lastFocusableElement = focusableElements[focusableElements.length - 1];
    }
    
    // Focus trap : boucler le focus dans la modal
    if (modal) {
        modal.addEventListener('keydown', function(event) {
            if (event.key !== 'Tab' || modal.style.display !== 'flex') return;
            
            if (event.shiftKey) {
                // Shift + Tab
                if (document.activeElement === firstFocusableElement) {
                    event.preventDefault();
                    lastFocusableElement.focus();
                }
            } else {
                // Tab
                if (document.activeElement === lastFocusableElement) {
                    event.preventDefault();
                    firstFocusableElement.focus();
                }
            }
        });
    }
    
    // Attacher les événements après le chargement du DOM
    function attachModalEvents() {
        // Fermer en cliquant sur l'overlay
        const overlay = document.querySelector('.energy-modal-overlay');
        if (overlay) {
            overlay.addEventListener('click', function(event) {
                // Fermer seulement si on clique directement sur l'overlay
                if (event.target === overlay) {
                    closeEnergyModal();
                }
            });
        }
        
        // Empêcher la fermeture en cliquant sur le contenu
        const modalContent = document.querySelector('.energy-modal-content');
        if (modalContent) {
            modalContent.addEventListener('click', function(event) {
                event.stopPropagation();
            });
        }
        
        // Fermer avec le bouton X
        const closeButton = document.querySelector('.energy-modal-close');
        if (closeButton) {
            closeButton.addEventListener('click', function(event) {
                event.preventDefault();
                event.stopPropagation();
                closeEnergyModal();
            });
        }
    }
    
    // Gestionnaire de soumission du formulaire
    function handleFormSubmit() {
        if (!form) {
            console.log('❌ Formulaire energyForm non trouvé');
            return;
        }
        
        console.log('✅ Gestionnaire de soumission attaché au formulaire énergie');
        
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('📤 Soumission du formulaire énergie interceptée');
            
            const submitButton = form.querySelector('button[type="submit"]');
            const originalButtonText = submitButton ? submitButton.textContent : 'Envoyer la demande';
            
            // Désactiver le bouton
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = 'Envoi en cours...';
            }
            
            try {
                // Récupérer les données du formulaire
                const formData = new FormData(form);
                
                // Convertir FormData en URLSearchParams pour Netlify Forms
                const params = new URLSearchParams();
                for (const [key, value] of formData.entries()) {
                    params.append(key, value);
                }
                
                // Envoyer à la fonction Netlify (qui sauvegarde dans la base de données)
                let response;
                let result;
                
                try {
                    response = await fetch('/.netlify/functions/submit-form', {
                        method: 'POST',
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: params.toString()
                    });
                    
                    try {
                        result = await response.json();
                    } catch (e) {
                        // Si la réponse n'est pas du JSON, considérer comme succès si status 200
                        if (response.ok) {
                            result = { success: true, message: 'Demande envoyée avec succès' };
                        } else {
                            throw new Error('Erreur lors de l\'envoi');
                        }
                    }
                } catch (fetchError) {
                    console.warn('Erreur fetch (peut-être en local):', fetchError);
                    // En local ou si la fonction n'existe pas, utiliser Netlify Forms directement
                    try {
                        response = await fetch('/', {
                            method: 'POST',
                            headers: { "Content-Type": "application/x-www-form-urlencoded" },
                            body: params.toString()
                        });
                        result = { success: response.ok, message: 'Demande envoyée avec succès' };
                    } catch (netlifyError) {
                        console.error('Erreur Netlify Forms:', netlifyError);
                        // En dernier recours, simuler un succès pour le test
                        result = { success: true, message: 'Demande envoyée avec succès' };
                    }
                }
                
                console.log('Résultat de la soumission:', result);
                
                if (result && (result.success || (response && response.ok))) {
                    // Afficher un message de succès dans la modal
                    const modalContent = document.querySelector('.energy-modal-content');
                    if (modalContent) {
                        console.log('✅ Préparation du message de succès');
                        
                        // Retirer le titre existant et le formulaire
                        const modalTitle = modalContent.querySelector('.energy-modal-title');
                        if (modalTitle) {
                            modalTitle.style.display = 'none';
                        }
                        
                        // Cacher complètement le formulaire
                        form.style.display = 'none';
                        form.style.visibility = 'hidden';
                        form.style.height = '0';
                        form.style.overflow = 'hidden';
                        
                        // Retirer les anciens messages s'ils existent
                        const existingSuccess = modalContent.querySelector('.energy-form-success');
                        if (existingSuccess) {
                            existingSuccess.remove();
                        }
                        
                        // Créer le message de succès
                        const successMessage = document.createElement('div');
                        successMessage.className = 'energy-form-success';
                        successMessage.style.cssText = `
                            width: 100%;
                            min-height: 300px;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            z-index: 1000;
                            position: relative;
                        `;
                        successMessage.innerHTML = `
                            <div style="text-align: center; padding: 3rem 2rem; width: 100%;">
                                <div style="font-size: 4rem; margin-bottom: 1.5rem;">✅</div>
                                <h2 style="color: var(--hub-primary, #FFD60A); margin-bottom: 1rem; font-size: 1.75rem; font-weight: 700;">Demande envoyée avec succès !</h2>
                                <p style="color: var(--text-light, #d1d5db); margin-bottom: 2rem; font-size: 1.1rem; line-height: 1.6;">
                                    Votre demande a été enregistrée. Nous vous contacterons dans les plus brefs délais.
                                </p>
                                <button type="button" class="btn btn-primary" onclick="closeEnergyModal()" style="margin-top: 1rem; padding: 0.75rem 2rem;">Fermer</button>
                            </div>
                        `;
                        
                        // Ajouter le message de succès AVANT le formulaire (pour qu'il soit visible)
                        modalContent.insertBefore(successMessage, form);
                        
                        console.log('✅ Message de succès affiché dans la modal');
                        
                        // Fermer automatiquement après 5 secondes
                        setTimeout(() => {
                            console.log('⏰ Fermeture automatique de la modal');
                            closeEnergyModal();
                        }, 5000);
                    } else {
                        console.error('❌ Modal content non trouvé');
                    }
                } else {
                    throw new Error(result ? result.message : 'Erreur lors de l\'envoi');
                }
            } catch (error) {
                console.error('Erreur lors de l\'envoi du formulaire:', error);
                
                // Afficher un message d'erreur
                const modalContent = document.querySelector('.energy-modal-content');
                if (modalContent) {
                    const errorMessage = document.createElement('div');
                    errorMessage.className = 'energy-form-error';
                    errorMessage.style.cssText = 'background: rgba(239, 68, 68, 0.1); border: 1px solid #EF4444; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; color: #EF4444;';
                    errorMessage.textContent = 'Une erreur est survenue. Veuillez réessayer plus tard.';
                    
                    // Insérer le message d'erreur avant le formulaire
                    form.insertBefore(errorMessage, form.firstChild);
                    
                    // Retirer le message après 5 secondes
                    setTimeout(() => {
                        if (errorMessage.parentNode) {
                            errorMessage.remove();
                        }
                    }, 5000);
                }
                
                // Réactiver le bouton
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.textContent = originalButtonText;
                }
            }
        });
    }
    
    // Attacher les événements au chargement
    function initFormLogic() {
        // Écouter les changements sur le select "besoin" pour mettre à jour les champs
        const besoinSelect = document.getElementById('energy-besoin');
        if (besoinSelect) {
            besoinSelect.addEventListener('change', updateFormFields);
        }
        
        // Gérer la soumission du formulaire
        handleFormSubmit();
    }
    
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            attachModalEvents();
            initFormLogic();
        });
    } else {
        // DOM déjà chargé, attacher immédiatement
        setTimeout(attachModalEvents, 0);
        setTimeout(initFormLogic, 0);
    }
    
    // Respecter prefers-reduced-motion pour les animations
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion && modal) {
        modal.style.transition = 'none';
    }
    
})();
